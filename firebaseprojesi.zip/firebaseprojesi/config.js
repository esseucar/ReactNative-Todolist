import firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyBfqoP0r2rJnqVRiVCMQJ1vdllv-QbnQEg",
  authDomain: "projem-d2e31.firebaseapp.com",
  projectId: "projem-d2e31",
  storageBucket: "projem-d2e31.appspot.com",
  messagingSenderId: "529097646945",
  appId: "1:529097646945:web:e34502e5343d8a201d1b20",
  measurementId: "G-0S8B4BW5SH"
};
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}
export {firebase};